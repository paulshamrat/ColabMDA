/*
 * This file is part of the GROMACS molecular simulation package.
 *
 * Copyright (c) 2020,2021, by the GROMACS development team, led by
 * Mark Abraham, David van der Spoel, Berk Hess, and Erik Lindahl,
 * and including many others, as listed in the AUTHORS file in the
 * top-level source directory and at http://www.gromacs.org.
 *
 * GROMACS is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * GROMACS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with GROMACS; if not, see
 * http://www.gnu.org/licenses, or write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA.
 *
 * If you want to redistribute modifications to GROMACS, please
 * consider that scientific software is very special. Version
 * control is crucial - bugs must be traceable. We will be happy to
 * consider code for inclusion in the official distribution, but
 * derived work must not be called official GROMACS. Details are found
 * in the README & COPYING files - if they are missing, get the
 * official version at http://www.gromacs.org.
 *
 * To help us fund GROMACS development, we humbly ask that you cite
 * the research papers on the package. Check out http://www.gromacs.org.
 */
/*! \inpublicapi \file
 * \brief
 * Implements ParticleSequencer class
 *
 * \author Victor Holanda <victor.holanda@cscs.ch>
 * \author Joe Jordan <ejjordan@kth.se>
 * \author Prashanth Kanduri <kanduri@cscs.ch>
 * \author Sebastian Keller <keller@cscs.ch>
 * \author Artem Zhmurov <zhmurov@gmail.com>
 */
#ifndef NBLIB_PARTICLESEQUENCER_H
#define NBLIB_PARTICLESEQUENCER_H

#include <tuple>
#include <unordered_map>
#include <vector>

#include "nblib/molecules.h"

namespace nblib
{

//! Helper class for Topology to keep track of particle IDs
class ParticleSequencer
{
    //! Alias for storing by (molecule name, molecule nr, residue name, particle name)
    using DataType = std::unordered_map<
            std::string,
            std::unordered_map<int, std::unordered_map<std::string, std::unordered_map<std::string, int>>>>;

public:
    //! Build sequence from a list of molecules
    void build(const std::vector<std::tuple<Molecule, int>>& moleculesList);

    //! Access ID by (molecule name, molecule nr, residue name, particle name)
    int operator()(const MoleculeName&, int, const ResidueName&, const ParticleName&) const;

private:
    DataType data_;
};

} // namespace nblib

#endif // NBLIB_PARTICLESEQUENCER_H
